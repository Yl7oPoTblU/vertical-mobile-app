package ru.tskvertical.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "vertical_reminders";

    @Override
    public void onReceive(Context context, Intent source) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Напоминания Вертикаль",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Локальные напоминания о тренировках, походах и снаряжении");
            channel.enableLights(true);
            channel.setLightColor(Color.rgb(0, 174, 239));
            manager.createNotificationChannel(channel);
        }

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                0,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String title = source.getStringExtra("title");
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        Notification notification = builder
                .setSmallIcon(R.drawable.vertical_app_icon)
                .setContentTitle("Вертикаль")
                .setContentText(title == null ? "Запланированное напоминание" : title)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setColor(Color.rgb(0, 174, 239))
                .build();
        manager.notify((int) System.currentTimeMillis(), notification);
    }
}
