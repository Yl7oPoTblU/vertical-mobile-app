package ru.tskvertical.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.backup.BackupManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 401;
    private static final String BACKUP_PREFERENCES = "vertical_backup";
    private static final String BACKUP_STATE_KEY = "state_json";
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xFF050505);
        getWindow().setNavigationBarColor(0xFF050505);
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF050505);
        webView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView source,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception ignored) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                }
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/jpeg", "image/png", "image/webp"});
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception error) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Не удалось открыть выбор фото", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveStateBackup(String stateJson) {
            if (stateJson == null || stateJson.isEmpty()) return;
            SharedPreferences preferences = getSharedPreferences(BACKUP_PREFERENCES, MODE_PRIVATE);
            if (preferences.edit().putString(BACKUP_STATE_KEY, stateJson).commit()) {
                new BackupManager(MainActivity.this).dataChanged();
            }
        }

        @JavascriptInterface
        public String loadStateBackup() {
            return getSharedPreferences(BACKUP_PREFERENCES, MODE_PRIVATE)
                    .getString(BACKUP_STATE_KEY, "");
        }

        @JavascriptInterface
        public void saveBase64File(String base64, String requestedName, String mimeType) {
            String filename = sanitizeFilename(requestedName);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                saveToPrivateDownloads(base64, filename);
                return;
            }
            try {
                byte[] content = Base64.decode(base64, Base64.DEFAULT);
                Uri destination;
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Вертикаль");
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                destination = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (destination == null) throw new IllegalStateException("Не удалось создать файл");

                try (OutputStream output = getContentResolver().openOutputStream(destination)) {
                    if (output == null) throw new IllegalStateException("Не удалось открыть файл");
                    output.write(content);
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(destination, values, null, null);
                showToast("Справка сохранена: Загрузки/Вертикаль/" + filename);
            } catch (Exception error) {
                saveToPrivateDownloads(base64, filename);
            }
        }

        private void saveToPrivateDownloads(String base64, String filename) {
            try {
                File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Вертикаль");
                if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Не удалось создать папку");
                File destination = new File(folder, filename);
                try (FileOutputStream output = new FileOutputStream(destination)) {
                    output.write(Base64.decode(base64, Base64.DEFAULT));
                }
                showToast("Справка сохранена в папке приложения");
            } catch (Exception error) {
                showToast("Не удалось сохранить справку");
            }
        }

        private String sanitizeFilename(String value) {
            String safe = value == null ? "Справка_Вертикаль.xlsx" : value.replaceAll("[\\\\/:*?\"<>|]", "_");
            return safe.toLowerCase().endsWith(".xlsx") ? safe : safe + ".xlsx";
        }

        private void showToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }
    }
}
