package ru.tskvertical.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.backup.BackupManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 401;
    private static final int LOCATION_PERMISSION_REQUEST = 402;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 403;
    private static final String BACKUP_PREFERENCES = "vertical_backup";
    private static final String BACKUP_STATE_KEY = "state_json";
    private WebView webView;
    private WebView printWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingSharedFileJson;
    private boolean pageReady;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xFF050505);
        getWindow().setNavigationBarColor(0xFF050505);
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF050505);
        webView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                deliverPendingSharedFile();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback
            ) {
                boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                        || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                callback.invoke(origin, granted, false);
            }

            @Override
            public boolean onShowFileChooser(
                    WebView source,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception ignored) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception error) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Не удалось открыть выбор фото", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        captureSharedFile(getIntent());
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureSharedFile(intent);
    }

    private void captureSharedFile(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        String sharedText = null;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            } else {
                uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            }
            if (uri == null) sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        }
        if (uri == null && sharedText == null) return;
        if (sharedText != null) {
            pendingSharedFileJson = sharedText;
            deliverPendingSharedFile();
            return;
        }
        try (InputStream input = getContentResolver().openInputStream(uri);
             Scanner scanner = input == null ? null : new Scanner(input, "UTF-8").useDelimiter("\\A")) {
            if (scanner == null || !scanner.hasNext()) throw new IllegalStateException("Файл пуст");
            pendingSharedFileJson = scanner.next();
            deliverPendingSharedFile();
        } catch (Exception error) {
            Toast.makeText(this, "Не удалось прочитать файл Вертикали", Toast.LENGTH_LONG).show();
        }
    }

    private void deliverPendingSharedFile() {
        if (!pageReady || webView == null || pendingSharedFileJson == null) return;
        String json = pendingSharedFileJson;
        pendingSharedFileJson = null;
        webView.evaluateJavascript("window.VerticalImportSharedFile && window.VerticalImportSharedFile(" + JSONObject.quote(json) + ")", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != LOCATION_PERMISSION_REQUEST || webView == null) return;
        boolean granted = false;
        for (int result : grantResults) {
            if (result == PackageManager.PERMISSION_GRANTED) {
                granted = true;
                break;
            }
        }
        webView.evaluateJavascript("window.VerticalLocationPermissionReady && window.VerticalLocationPermissionReady(" + granted + ")", null);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (printWebView != null) {
            printWebView.destroy();
            printWebView = null;
        }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveStateBackup(String stateJson) {
            if (stateJson == null || stateJson.isEmpty()) return;
            SharedPreferences preferences = getSharedPreferences(BACKUP_PREFERENCES, MODE_PRIVATE);
            if (preferences.edit().putString(BACKUP_STATE_KEY, stateJson).commit()) {
                new BackupManager(MainActivity.this).dataChanged();
            }
        }

        @JavascriptInterface
        public String loadStateBackup() {
            return getSharedPreferences(BACKUP_PREFERENCES, MODE_PRIVATE)
                    .getString(BACKUP_STATE_KEY, "");
        }

        @JavascriptInterface
        public void requestLocationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                        || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    webView.evaluateJavascript("window.VerticalLocationPermissionReady && window.VerticalLocationPermissionReady(true)", null);
                    return;
                }
                requestPermissions(
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                        LOCATION_PERMISSION_REQUEST
                );
            });
        }

        @JavascriptInterface
        public void printPdf(String html) {
            if (html == null || html.isEmpty()) return;
            runOnUiThread(() -> {
                if (printWebView != null) printWebView.destroy();
                printWebView = new WebView(MainActivity.this);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
                        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                        String jobName = "Вертикаль_" + date;
                        PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                .build();
                        manager.print(jobName, view.createPrintDocumentAdapter(jobName), attributes);
                    }
                });
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface
        public void scheduleReminder(String id, String title, long dueAt) {
            if (id == null || id.isEmpty() || dueAt <= System.currentTimeMillis()) return;
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                }
                Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                intent.putExtra("title", title == null || title.isEmpty() ? "Напоминание" : title);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        MainActivity.this,
                        id.hashCode(),
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );
                AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, dueAt, pendingIntent);
            });
        }

        @JavascriptInterface
        public void cancelReminder(String id) {
            if (id == null || id.isEmpty()) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        MainActivity.this,
                        id.hashCode(),
                        intent,
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                );
                if (pendingIntent == null) return;
                AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
                manager.cancel(pendingIntent);
                pendingIntent.cancel();
            });
        }

        @JavascriptInterface
        public void saveBase64File(String base64, String requestedName, String mimeType) {
            String filename = sanitizeFilename(requestedName);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                saveToPrivateDownloads(base64, filename);
                return;
            }
            try {
                byte[] content = Base64.decode(base64, Base64.DEFAULT);
                Uri destination;
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Вертикаль");
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                destination = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (destination == null) throw new IllegalStateException("Не удалось создать файл");

                try (OutputStream output = getContentResolver().openOutputStream(destination)) {
                    if (output == null) throw new IllegalStateException("Не удалось открыть файл");
                    output.write(content);
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(destination, values, null, null);
                showToast("Справка сохранена: Загрузки/Вертикаль/" + filename);
            } catch (Exception error) {
                saveToPrivateDownloads(base64, filename);
            }
        }

        @JavascriptInterface
        public void shareBase64File(String base64, String requestedName, String mimeType, String chooserTitle) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    saveToPrivateDownloads(base64, sanitizeSharedFilename(requestedName));
                    showToast("Файл сохранён — отправьте его из папки приложения");
                    return;
                }
                try {
                    String filename = sanitizeSharedFilename(requestedName);
                    byte[] content = Base64.decode(base64, Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/json" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Вертикаль");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri destination = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (destination == null) throw new IllegalStateException("Не удалось создать файл");
                    try (OutputStream output = getContentResolver().openOutputStream(destination)) {
                        if (output == null) throw new IllegalStateException("Не удалось открыть файл");
                        output.write(content);
                    }
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(destination, values, null, null);

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType(mimeType == null ? "application/json" : mimeType);
                    share.putExtra(Intent.EXTRA_STREAM, destination);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, chooserTitle == null ? "Поделиться" : chooserTitle));
                } catch (Exception error) {
                    showToast("Не удалось подготовить файл для отправки");
                }
            });
        }

        private void saveToPrivateDownloads(String base64, String filename) {
            try {
                File folder = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Вертикаль");
                if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Не удалось создать папку");
                File destination = new File(folder, filename);
                try (FileOutputStream output = new FileOutputStream(destination)) {
                    output.write(Base64.decode(base64, Base64.DEFAULT));
                }
                showToast("Справка сохранена в папке приложения");
            } catch (Exception error) {
                showToast("Не удалось сохранить справку");
            }
        }

        private String sanitizeFilename(String value) {
            String safe = value == null ? "Справка_Вертикаль.xlsx" : value.replaceAll("[\\\\/:*?\"<>|]", "_");
            return safe.toLowerCase().endsWith(".xlsx") ? safe : safe + ".xlsx";
        }

        private String sanitizeSharedFilename(String value) {
            String safe = value == null ? "Файл_Вертикаль.json" : value.replaceAll("[\\\\/:*?\"<>|]", "_");
            return safe.toLowerCase().endsWith(".json") ? safe : safe + ".json";
        }

        private void showToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }
    }
}
