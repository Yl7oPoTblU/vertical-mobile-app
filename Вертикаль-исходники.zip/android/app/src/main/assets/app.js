(() => {
  "use strict";

  const STORAGE_KEY = "vertical-mobile-profile-v2";
  const routeLabels = {
    mountain: "Горные",
    hiking: "Пешие (многодневные)",
    water: "Водные",
    speleo: "Спелео",
  };
  const routeCoefficients = {
    mountain: 7,
    hiking: 5,
    water: 4,
    speleo: 3,
  };
  const membershipLabels = {
    section: "Член секции",
    team: "Член команды",
    club: "Член клуба",
  };
  const sportsGrades = [
    { value: "Без разряда", score: 0 },
    { value: "III юношеский разряд", score: 1 },
    { value: "II юношеский разряд", score: 2 },
    { value: "I юношеский разряд", score: 3 },
    { value: "III спортивный разряд", score: 4 },
    { value: "II спортивный разряд", score: 5 },
    { value: "I спортивный разряд", score: 6 },
    { value: "КМС — кандидат в мастера спорта", score: 8 },
    { value: "Мастер спорта (МС)", score: 10 },
    { value: "Мастер спорта международного класса (МСМК)", score: 12 },
  ];

  const initialData = {
    schemaVersion: 4,
    profile: {
      name: "Иванов Иван Иванович",
      age: 0,
      birthDate: "",
      memberSince: "",
      grade: "Без разряда",
      gradeScore: 0,
      photo: "",
    },
    membership: {
      level: "section",
    },
    routes: {
      mountain: 0,
      hiking: 0,
      water: 0,
      speleo: 0,
    },
    peaks: [],
    activity: {
      eventsOrganized: 0,
      competitionsParticipated: 0,
      trainingsOrganized: 0,
      trainingsVisited: 0,
      runToday: 0,
      runWeek: 0,
      runTotal: 0,
    },
    competitions: [],
    trainingSessions: [],
    tests: [],
    notes: [],
    weekendHikes: [],
    runTracks: [],
    norms: [
      { id: "abs", name: "Пресс за минуту", type: "count", current: 0, target: 60, unit: "раз" },
      { id: "pushups", name: "Отжимания", type: "count", current: 0, target: 50, unit: "раз" },
      { id: "pullups", name: "Подтягивания", type: "count", current: 0, target: 15, unit: "раз" },
      { id: "jumaring", name: "Жумаринг 50 м", type: "time", current: 0, target: 5, unit: "мин" },
      { id: "run", name: "Бег 1 км", type: "time", current: 0, target: 5, unit: "мин" },
    ],
  };

  let state = loadState();
  let activeTab = "profile";
  let submitHandler = null;
  let toastTimer = 0;
  let lastPromotionToastKey = "";

  const app = document.querySelector("#app");
  const dialog = document.querySelector("#edit-dialog");
  const form = document.querySelector("#edit-form");
  const dialogTitle = document.querySelector("#dialog-title");
  const dialogBody = document.querySelector("#dialog-body");
  const toast = document.querySelector("#toast");
  let splash = document.querySelector("#splash");
  let splashTimer = 0;

  function finishSplash() {
    if (!splash || splash.classList.contains("is-leaving")) return;
    splash.classList.add("is-leaving");
    document.body.classList.remove("splash-active");
    const closingSplash = splash;
    window.setTimeout(() => {
      if (closingSplash === splash) closingSplash.hidden = true;
    }, 520);
  }

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function scheduleSplashFinish() {
    window.clearTimeout(splashTimer);
    splashTimer = window.setTimeout(finishSplash, reducedMotion ? 1500 : 3280);
  }

  scheduleSplashFinish();

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function migrateState(saved) {
    if (!saved || !saved.profile || !saved.routes) return clone(initialData);
    const base = clone(initialData);
    const migrated = {
      ...base,
      ...saved,
      profile: { ...base.profile, ...saved.profile },
      routes: { ...base.routes, ...saved.routes },
      activity: { ...base.activity, ...saved.activity },
      peaks: Array.isArray(saved.peaks) ? saved.peaks : base.peaks,
      norms: Array.isArray(saved.norms) ? saved.norms : base.norms,
      membership: { ...base.membership, ...saved.membership },
      competitions: Array.isArray(saved.competitions) ? saved.competitions : base.competitions,
      trainingSessions: Array.isArray(saved.trainingSessions) ? saved.trainingSessions : base.trainingSessions,
      tests: Array.isArray(saved.tests) ? saved.tests : base.tests,
      notes: Array.isArray(saved.notes) ? saved.notes : base.notes,
      weekendHikes: Array.isArray(saved.weekendHikes) ? saved.weekendHikes : base.weekendHikes,
      runTracks: Array.isArray(saved.runTracks) ? saved.runTracks : base.runTracks,
    };
    delete migrated.debugRatingBoost;
    delete migrated.routes.score;
    delete migrated.passes;
    migrated.tests.forEach((test) => { delete test.coefficient; });
    migrated.notes.forEach((note) => {
      note.title = String(note.title ?? "").trim() || String(note.text ?? "").trim().split(/\r?\n/)[0].slice(0, 60) || "Без названия";
    });
    migrated.competitions.forEach((competition) => { competition.place = normalizeCompetitionPlace(competition.place); });
    migrated.profile.grade = normalizeGrade(migrated.profile.grade);
    migrated.profile.gradeScore = gradeScoreFor(migrated.profile.grade);
    if (!membershipLabels[migrated.membership.level]) migrated.membership.level = "section";
    if (number(migrated.schemaVersion) < 3) {
      const previouslyIncludedHikes = migrated.weekendHikes.reduce((sum, hike) => sum + number(hike.distance), 0);
      migrated.activity.runTotal = Math.max(0, number(migrated.activity.runTotal) - previouslyIncludedHikes);
    }
    migrated.schemaVersion = 4;
    return migrated;
  }

  function loadState() {
    try {
      const localState = localStorage.getItem(STORAGE_KEY);
      const androidState = !localState && window.Android?.loadStateBackup ? window.Android.loadStateBackup() : "";
      const iosState = !localState && !androidState ? window.__VERTICAL_NATIVE_BACKUP__ : "";
      const nativeState = androidState || iosState;
      const migrated = migrateState(JSON.parse(localState || nativeState));
      if (nativeState) localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
      return migrated;
    } catch {
      return clone(initialData);
    }
  }

  function saveState() {
    const serialized = JSON.stringify(state);
    localStorage.setItem(STORAGE_KEY, serialized);
    if (window.Android?.saveStateBackup) window.Android.saveStateBackup(serialized);
    if (window.webkit?.messageHandlers?.saveState && !window.__VERTICAL_AWAITING_CLOUD_RESTORE__) {
      window.webkit.messageHandlers.saveState.postMessage(serialized);
    }
  }

  window.VerticalNativeRestore = (serialized) => {
    try {
      state = migrateState(JSON.parse(String(serialized ?? "")));
      window.__VERTICAL_AWAITING_CLOUD_RESTORE__ = false;
      saveState();
      render();
      showToast("Данные восстановлены из iCloud");
      return true;
    } catch {
      return false;
    }
  };

  window.VerticalNativeFinishRestore = () => {
    window.__VERTICAL_AWAITING_CLOUD_RESTORE__ = false;
    saveState();
  };

  function number(value, fallback = 0) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }

  function formatNumber(value, digits = 1) {
    return new Intl.NumberFormat("ru-RU", {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits,
    }).format(value);
  }

  function profileAge() {
    if (!state.profile.birthDate) return number(state.profile.age);
    const birth = new Date(`${state.profile.birthDate}T00:00:00`);
    if (Number.isNaN(birth.getTime())) return 0;
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const beforeBirthday = today.getMonth() < birth.getMonth()
      || (today.getMonth() === birth.getMonth() && today.getDate() < birth.getDate());
    if (beforeBirthday) age -= 1;
    return Math.max(0, age);
  }

  function daysSince(value) {
    if (!value) return 0;
    const start = new Date(`${value}T00:00:00`);
    if (Number.isNaN(start.getTime())) return 0;
    const today = new Date();
    const current = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    return Math.max(0, Math.floor((current - start) / 86400000));
  }

  function walkedDistance() {
    return state.weekendHikes.reduce((sum, hike) => sum + number(hike.distance), 0);
  }

  function peakCountsByCategory() {
    return state.peaks.reduce((totals, peak) => {
      if (Object.prototype.hasOwnProperty.call(totals, peak.category)) totals[peak.category] += number(peak.count);
      return totals;
    }, { "3": 0, "2": 0, "1": 0, nk: 0 });
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function initials(name) {
    return String(name)
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? "")
      .join("") || "В";
  }

  function avatarMarkup(size = "normal") {
    const content = state.profile.photo
      ? `<img src="${escapeHtml(state.profile.photo)}" alt="Фото участника" />`
      : `<img src="assets/vertical-logo.png" alt="Логотип клуба Вертикаль" />`;
    return `<div class="avatar ${size === "large" ? "avatar-large" : ""}">${content}</div>`;
  }

  function membershipLabel() {
    return membershipLabels[state.membership?.level] ?? membershipLabels.section;
  }

  function normalizeGrade(value) {
    const grade = String(value ?? "").trim();
    const aliases = {
      "1 спортивный разряд": "I спортивный разряд",
      "2 спортивный разряд": "II спортивный разряд",
      "3 спортивный разряд": "III спортивный разряд",
    };
    const normalized = aliases[grade.toLowerCase()] ?? grade;
    return sportsGrades.some((item) => item.value === normalized) ? normalized : "Без разряда";
  }

  function gradeScoreFor(grade) {
    return sportsGrades.find((item) => item.value === normalizeGrade(grade))?.score ?? 0;
  }

  function testScore(test) {
    return number(test.points);
  }

  function normalizeCompetitionPlace(value) {
    const place = String(value ?? "").trim().toLowerCase();
    if (/^(1|1-е|1 место|первое)$/.test(place)) return "1";
    if (/^(2|2-е|2 место|второе)$/.test(place)) return "2";
    if (/^(3|3-е|3 место|третье)$/.test(place)) return "3";
    return "none";
  }

  function competitionPlaceLabel(value) {
    const place = normalizeCompetitionPlace(value);
    return place === "none" ? "Участие без места" : `${place} место`;
  }

  function competitionScore(competition) {
    return { "1": 3, "2": 2, "3": 1, none: 0.5 }[normalizeCompetitionPlace(competition.place)];
  }

  function peakScore(peak) {
    const points = { "3": 2.4, "2": 1.8, "1": 1.2, nk: 0.6 }[peak.category] ?? 0;
    return number(peak.count) * points;
  }

  function routeScore(routes = state.routes) {
    return Object.keys(routeLabels).reduce((sum, key) => sum + number(routes[key]) * routeCoefficients[key], 0);
  }

  function normScore(norm) {
    if (!number(norm.target) || (norm.type === "time" && number(norm.current) <= 0)) return 0;
    const ratio = number(norm.current) / number(norm.target);
    const score = norm.type === "time" ? 2 - ratio : ratio;
    return Math.max(0, Math.min(score, 5));
  }

  function calculate() {
    const routeTotal = Object.keys(routeLabels).reduce((sum, key) => sum + number(state.routes[key]), 0);
    const routes = routeScore();
    const peaks = state.peaks.reduce((sum, peak) => sum + peakScore(peak), 0);
    const norms = state.norms.reduce((sum, norm) => sum + normScore(norm), 0);
    const tests = state.tests.reduce((sum, test) => sum + testScore(test), 0);
    const run = number(state.activity.runTotal) * 0.05;
    const distance = walkedDistance();
    const grade = number(state.profile.gradeScore);
    const competitionCount = Math.max(number(state.activity.competitionsParticipated), state.competitions.length);
    const recordedCompetitionPoints = state.competitions.reduce((sum, competition) => sum + competitionScore(competition), 0);
    const competitions = recordedCompetitionPoints + Math.max(0, competitionCount - state.competitions.length) * 0.5;
    const weekendHikes = state.weekendHikes.length;
    const events = number(state.activity.eventsOrganized);
    const trainingsOrganized = number(state.activity.trainingsOrganized) * 0.08;
    const trainingCount = state.trainingSessions.length;
    const trainingsVisited = trainingCount * 0.3;
    const personal = routes + peaks + norms + tests + run + grade + competitions + weekendHikes + trainingsVisited;
    const team = events + competitions + trainingsOrganized + trainingsVisited + grade;

    return { routeTotal, routeScore: routes, peaks, norms, tests, run, distance, grade, competitions, competitionCount, weekendHikes, events, trainingsOrganized, trainingsVisited, trainingCount, personal, team };
  }

  function getPromotionNotice(scores) {
    if (state.membership.level === "section" && scores.personal >= 30) {
      return {
        key: "team",
        title: "Доступно повышение до члена команды",
        text: "Рейтинг достиг 30 баллов. Получите код у руководителя и введите его в профиле.",
      };
    }
    if (state.membership.level === "team" && scores.personal >= 60) {
      return {
        key: "club",
        title: "Доступно повышение до члена клуба",
        text: "Рейтинг достиг 60 баллов. Получите код повышения и введите его в профиле.",
      };
    }
    return null;
  }

  function promotionCard(scores) {
    const notice = getPromotionNotice(scores);
    if (!notice) return "";
    return `<article class="promotion-card"><span class="promotion-icon">!</span><div><strong>${notice.title}</strong><p>${notice.text}</p><button class="text-button" type="button" data-action="enter-membership-code">Ввести код</button></div></article>`;
  }

  function schedulePromotionToast(scores) {
    const notice = getPromotionNotice(scores);
    if (!notice || notice.key === lastPromotionToastKey) return;
    lastPromotionToastKey = notice.key;
    window.setTimeout(() => showToast(notice.title), splash?.hidden ? 250 : 3500);
  }

  function enforceMembershipThreshold(scores) {
    const currentLevel = state.membership.level;
    let nextLevel = currentLevel;

    if (currentLevel === "club" && scores.personal < 60) {
      nextLevel = scores.personal >= 30 ? "team" : "section";
    } else if (currentLevel === "team" && scores.personal < 30) {
      nextLevel = "section";
    }

    if (nextLevel === currentLevel) return "";
    state.membership.level = nextLevel;
    lastPromotionToastKey = "";
    saveState();
    return `Рейтинг ниже порога. Категория изменена: ${membershipLabel()}`;
  }

  function render() {
    const scores = calculate();
    const downgradeMessage = enforceMembershipThreshold(scores);
    app.innerHTML = [
      renderRoutes(scores),
      renderActivity(scores),
      renderNotes(),
      renderProfile(scores),
    ].join("");
    switchTab(activeTab, false);
    schedulePromotionToast(scores);
    if (downgradeMessage) window.setTimeout(() => showToast(downgradeMessage), 80);
  }

  function renderHome(scores) {
    return `
      <section class="screen" data-screen="home">
        <article class="profile-hero">
          <div class="person-row">
            ${avatarMarkup()}
            <div class="person-meta">
              <span class="eyebrow">${membershipLabel()}</span>
              <h1>${escapeHtml(state.profile.name)}</h1>
              <p>${profileAge()} лет · ${escapeHtml(state.profile.grade)}</p>
            </div>
            <button class="mini-edit" type="button" data-action="edit-profile">Изменить</button>
          </div>
          <div class="rating-grid">
            <div>
              <p class="rating-label">Личный рейтинг</p>
              <p class="rating-value">${formatNumber(scores.personal)}<span>балла</span></p>
            </div>
            <div class="team-score">
              <span>Командный</span>
              <strong>${formatNumber(scores.team)}</strong>
            </div>
          </div>
          <button class="primary-button hero-action" type="button" data-action="download-report">
            Создать справку
          </button>
        </article>

        ${promotionCard(scores)}

        <section class="section">
          <div class="section-head"><h2>Мои показатели</h2></div>
          <div class="metric-grid">
            ${metric("△", scores.routeTotal, "категорированных маршрутов")}
            ${metric("⌁", state.peaks.length, "вершин и перевалов")}
            ${metric("↗", scores.trainingCount, "посещённых тренировок")}
            ${metric("○", `${formatNumber(state.activity.runTotal)} км`, "бег")}
          </div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Сводка</h2></div>
          <article class="insight-card">
            <div class="insight-mark">V</div>
            <div>
              <h3>Основу рейтинга дают восхождения</h3>
              <p>${formatNumber(scores.peaks)} балла из ${formatNumber(scores.personal)} начислено за вершины и перевалы.</p>
            </div>
          </article>
        </section>
      </section>`;
  }

  function metric(icon, value, label) {
    return `<article class="metric-card"><span class="metric-icon">${icon}</span><strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span></article>`;
  }

  function renderRoutes(scores) {
    const peakCounts = peakCountsByCategory();
    const max = Math.max(...Object.keys(routeLabels).map((key) => number(state.routes[key])), 1);
    const rows = Object.entries(routeLabels)
      .map(([key, label]) => {
        const value = number(state.routes[key]);
        return `<div class="distribution-row"><span>${label}</span><div class="bar-track"><i style="width:${(value / max) * 100}%"></i></div><strong>${value}</strong></div>`;
      })
      .join("");

    const peaks = state.peaks
      .map((peak) => `
        <article class="peak-card ${peak.photo ? "with-photo" : ""}">
          ${peak.photo ? `<img class="peak-photo" src="${escapeHtml(peak.photo)}" alt="Фото восхождения ${escapeHtml(peak.name)}" />` : ""}
          <div>
            <div class="peak-title"><span class="category-chip">${escapeHtml(peak.category)}</span><strong>${escapeHtml(peak.name)}</strong></div>
            <div class="peak-sub">Восхождений: ${number(peak.count)}</div>
            <div class="peak-date">${peak.conqueredAt ? formatDateTime(peak.conqueredAt) : "Дата покорения не указана"}</div>
          </div>
          <div class="peak-actions">
            <div class="peak-score"><strong>${formatNumber(peakScore(peak))}</strong><span>балла</span></div>
            <button class="card-edit-button" type="button" data-action="edit-peak" data-id="${escapeHtml(peak.id)}">Изменить</button>
          </div>
        </article>`)
      .join("");

    const weekendHikes = state.weekendHikes
      .map((hike) => `
        <article class="weekend-hike-card">
          <div class="weekend-hike-top">
            <span class="category-chip">+1</span>
            <div><strong>${escapeHtml(hike.name)}</strong><span>${escapeHtml(hike.location)}</span></div>
            <button class="card-edit-button" type="button" data-action="edit-weekend-hike" data-id="${escapeHtml(hike.id)}">Изменить</button>
          </div>
          <div class="weekend-hike-date">${formatDate(hike.date)}</div>
          <div class="weekend-hike-stats"><span>${formatNumber(hike.distance)} км</span><span>${escapeHtml(formatHikeDuration(hike.duration))}</span></div>
          ${hike.description ? `<p>${escapeHtml(hike.description)}</p>` : ""}
        </article>`)
      .join("");

    return `
      <section class="screen" data-screen="routes">
        <header class="screen-heading"><span class="eyebrow">Мой опыт</span><h1>Маршруты</h1><p>Категории маршрутов, походы выходного дня, покорённые вершины и перевалы.</p></header>
        <div class="section-head"><h2>Категорированные маршруты</h2><button class="text-button" type="button" data-action="edit-routes">Изменить</button></div>
        <article class="route-summary">
          <div class="route-total"><strong>${scores.routeTotal}</strong><span>+${formatNumber(scores.routeScore)} к рейтингу</span></div>
          <p>Всего категорированных маршрутов</p>
          <div class="distribution-list">${rows}</div>
        </article>

        <section class="section">
          <div class="section-head"><h2>Походы выходного дня <small>Однодневные · +${formatNumber(scores.weekendHikes, 0)} к рейтингу</small></h2><button class="text-button" type="button" data-action="add-weekend-hike">Добавить</button></div>
          <div class="weekend-hike-list">${weekendHikes || `<article class="empty-card">Добавьте поход в районе города. Каждая запись принесёт 1 балл личного рейтинга.</article>`}</div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Вершины и перевалы</h2><button class="text-button" type="button" data-action="add-peak">Добавить</button></div>
          <div class="peak-list">${peaks || `<article class="insight-card"><p>Пока нет добавленных восхождений.</p></article>`}</div>
        </section>

        <section class="section">
          <div class="section-head"><h2>По категориям</h2></div>
          <p class="section-note auto-data-note">Значения формируются автоматически из записей выше.</p>
          <div class="activity-strip four-columns">
            <div><strong>${formatNumber(peakCounts["3"], 0)}</strong><span>3 к.с.</span></div>
            <div><strong>${formatNumber(peakCounts["2"], 0)}</strong><span>2 к.с.</span></div>
            <div><strong>${formatNumber(peakCounts["1"], 0)}</strong><span>1 к.с.</span></div>
            <div><strong>${formatNumber(peakCounts.nk, 0)}</strong><span>н/к</span></div>
          </div>
        </section>
      </section>`;
  }

  function renderActivity(scores) {
    const normCards = state.norms.map((norm) => {
      const score = normScore(norm);
      const progress = Math.max(0, Math.min(score / 1.2, 1)) * 100;
      return `
        <article class="norm-card">
          <div class="norm-top"><strong>${escapeHtml(norm.name)}</strong><span>${Math.round(score * 100)}%</span></div>
          <div class="norm-values"><span>Результат: ${formatNorm(norm.current, norm)}</span><span>Норматив: ${formatNorm(norm.target, norm)}</span></div>
          <div class="bar-track"><i style="width:${progress}%"></i></div>
        </article>`;
    }).join("");
    const testCards = state.tests.map((test) => `
      <article class="record-card">
        <div><strong>${escapeHtml(test.name)}</strong><span>${test.date ? `${formatDate(test.date)} · ` : "Дата не указана · "}${formatNumber(testScore(test))} балла к личному рейтингу</span></div>
        <button class="card-edit-button" type="button" data-action="edit-test" data-id="${escapeHtml(test.id)}">Изменить</button>
      </article>`).join("");
    const competitionCards = state.competitions.map((competition) => `
      <article class="competition-card ${competition.photo ? "with-photo" : ""}">
        ${competition.photo ? `<img src="${escapeHtml(competition.photo)}" alt="Фото с соревнования ${escapeHtml(competition.name)}" />` : ""}
        <div class="competition-content">
          <strong>${escapeHtml(competition.name)}</strong>
          <span>${escapeHtml(competition.location)} · ${formatDate(competition.date)}</span>
          <span class="place-chip">${escapeHtml(competitionPlaceLabel(competition.place))} · +${formatNumber(competitionScore(competition))}</span>
        </div>
        <button class="card-edit-button" type="button" data-action="edit-competition" data-id="${escapeHtml(competition.id)}">Изменить</button>
      </article>`).join("");
    const runTrackCards = state.runTracks.map((track) => `
      <article class="run-track-card ${track.photo ? "with-photo" : ""}">
        ${track.photo ? `<img src="${escapeHtml(track.photo)}" alt="Фото трека пробежки ${escapeHtml(track.name)}" />` : ""}
        <div class="run-track-content">
          <div class="run-track-title"><strong>${escapeHtml(track.name)}</strong><span>${formatNumber(track.distance)} км</span></div>
          <span>${escapeHtml(track.route)} · ${track.runAt ? formatDateTime(track.runAt) : "Дата не указана"}</span>
          ${track.note ? `<p>${escapeHtml(track.note)}</p>` : ""}
        </div>
        <button class="card-edit-button" type="button" data-action="edit-run-track" data-id="${escapeHtml(track.id)}">Изменить</button>
      </article>`).join("");
    const trainingTotals = state.trainingSessions.reduce((totals, training) => {
      totals.duration += number(training.durationMinutes);
      totals.distance += number(training.distance);
      totals.approaches += number(training.approachCount);
      totals.actions += number(training.approachCount) * number(training.actionsPerApproach);
      return totals;
    }, { duration: 0, distance: 0, approaches: 0, actions: 0 });
    const trainingCards = state.trainingSessions.map((training) => {
      const totalActions = number(training.approachCount) * number(training.actionsPerApproach);
      return `
        <article class="training-card">
          <div class="training-card-main">
            <div class="training-card-title"><strong>${escapeHtml(training.name)}</strong><span>${formatTrainingDuration(training.durationMinutes)}</span></div>
            ${training.description ? `<p>${escapeHtml(training.description)}</p>` : ""}
            <div class="training-details">
              <span>${formatNumber(training.distance)} км</span>
              <span>${formatNumber(training.approachCount, 0)} подходов</span>
              <span>${formatNumber(training.actionsPerApproach, 0)} действий в подходе</span>
              ${training.approachLabel ? `<span>${escapeHtml(training.approachLabel)}</span>` : ""}
              <span>${formatNumber(totalActions, 0)} действий всего</span>
            </div>
          </div>
          <button class="card-edit-button" type="button" data-action="edit-training" data-id="${escapeHtml(training.id)}">Изменить</button>
        </article>`;
    }).join("");

    return `
      <section class="screen" data-screen="activity">
        <header class="screen-heading"><span class="eyebrow">Тренировки</span><h1>Активность</h1><p>Командный вклад, треки бега и выполнение физических нормативов.</p></header>
        <div class="section-head"><h2>Командный вклад</h2><button class="text-button" type="button" data-action="edit-training-stats">Изменить</button></div>
        <div class="metric-grid">
          ${metric("+", state.activity.eventsOrganized, "организованных мероприятий")}
          ${metric("★", scores.competitionCount, "участий в соревнованиях")}
          ${metric("↟", state.activity.trainingsOrganized, "организованных тренировок")}
          ${metric("✓", scores.trainingCount, "посещённых тренировок")}
        </div>
        <article class="insight-card team-rating-summary"><div class="insight-mark">↗</div><div><h3>Командный рейтинг: ${formatNumber(scores.team)}</h3><p>Включает разряд, мероприятия, соревнования и тренировки. Каждая посещённая тренировка также учитывается в личном рейтинге.</p></div></article>

        <section class="section">
          <div class="section-head"><h2>Тренировки <small>${formatNumber(scores.trainingCount, 0)} посещено · +${formatNumber(scores.trainingsVisited)} к обоим рейтингам</small></h2><button class="text-button" type="button" data-action="add-training">Добавить тренировку</button></div>
          <div class="activity-strip four-columns training-summary">
            <div><strong>${formatTrainingDuration(trainingTotals.duration)}</strong><span>общее время занятий</span></div>
            <div><strong>${formatNumber(trainingTotals.distance)}</strong><span>км преодолено</span></div>
            <div><strong>${formatNumber(trainingTotals.approaches, 0)}</strong><span>подходов</span></div>
            <div><strong>${formatNumber(trainingTotals.actions, 0)}</strong><span>действий</span></div>
          </div>
          <div class="training-list">${trainingCards || `<article class="empty-card">Добавьте тренировку, её описание, время, километраж и выполненные подходы.</article>`}</div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Соревнования <small>+${formatNumber(scores.competitions)} к рейтингу</small></h2><button class="text-button" type="button" data-action="add-competition">Добавить</button></div>
          <div class="record-list">${competitionCards || `<article class="empty-card">Добавьте название, место проведения, дату, занятое место и фотографию.</article>`}</div>
          <p class="section-note">Участие без места — 0,5 · 3 место — 1 · 2 место — 2 · 1 место — 3 балла.</p>
        </section>

        <section class="section">
          <div class="section-head"><h2>Бег</h2><div class="section-actions"><button class="text-button" type="button" data-action="edit-running">Итоги</button><button class="text-button" type="button" data-action="add-run-track">Добавить трек</button></div></div>
          <div class="activity-strip">
            <div><strong>${formatNumber(state.activity.runToday)}</strong><span>км сегодня</span></div>
            <div><strong>${formatNumber(state.activity.runWeek)}</strong><span>км за неделю</span></div>
            <div><strong>${formatNumber(state.activity.runTotal)}</strong><span>км бега всего</span></div>
          </div>
          <div class="run-track-list">${runTrackCards || `<article class="empty-card">Добавьте маршрут, дистанцию, дату и фотографию трека пробежки.</article>`}</div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Пройденный километраж</h2></div>
          <article class="distance-summary">
            <span>Без учёта бега</span>
            <strong>${formatNumber(scores.distance)} <small>км</small></strong>
            <p>Рассчитывается автоматически по расстоянию в записях о походах.</p>
          </article>
        </section>

        <section class="section">
          <div class="section-head"><h2>Тесты <small>+${formatNumber(scores.tests)} к рейтингу</small></h2><button class="text-button" type="button" data-action="add-test">Добавить</button></div>
          <div class="record-list">${testCards || `<article class="empty-card">Пока нет добавленных тестов.</article>`}</div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Нормативы</h2><button class="text-button" type="button" data-action="edit-norms">Изменить</button></div>
          <div class="norm-list">${normCards}</div>
        </section>
      </section>`;
  }

  function renderNotes() {
    const noteRows = state.notes.map((note) => `
      <article class="note-row">
        <div class="note-row-content">
          <strong>${escapeHtml(note.title || "Без названия")}</strong>
          <span>${new Date(note.updatedAt || note.createdAt).toLocaleString("ru-RU")}</span>
          <p>${escapeHtml(note.text)}</p>
        </div>
        <div class="note-row-actions">
          <button class="note-icon-button edit" type="button" data-action="edit-note" data-id="${escapeHtml(note.id)}" aria-label="Редактировать заметку">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 20 4.2-1 10.9-10.9a2.1 2.1 0 0 0-3-3L5.2 16z"/><path d="m14.8 6.2 3 3"/></svg>
          </button>
          <button class="note-icon-button delete" type="button" data-action="delete-note" data-id="${escapeHtml(note.id)}" aria-label="Удалить заметку">×</button>
        </div>
      </article>`).join("");

    return `
      <section class="screen" data-screen="notes">
        <header class="screen-heading"><span class="eyebrow">Личные записи</span><h1>Заметки</h1><p>Записывайте планы, наблюдения и любую важную информацию.</p></header>
        <form class="note-publisher" data-note-publisher>
          <div class="form-field"><label for="quick-note-title">Название заметки</label><input id="quick-note-title" name="title" maxlength="80" placeholder="Например, План на неделю" required /></div>
          <div class="form-field"><label for="quick-note-text">Текст заметки</label><textarea id="quick-note-text" name="text" rows="6" placeholder="Введите текст заметки" required></textarea></div>
          <button class="primary-button" type="submit">Опубликовать</button>
        </form>
        <section class="section note-feed-section">
          <div class="section-head"><h2>Опубликованные заметки <small>${state.notes.length}</small></h2></div>
          <div class="note-list">${noteRows || `<article class="empty-card">Опубликованные заметки появятся здесь.</article>`}</div>
        </section>
      </section>`;
  }

  function renderProfile(scores) {
    const ratingRows = (items) => items.map(([label, value]) => `<div class="rating-breakdown-row"><span>${label}</span><strong>${formatNumber(value)}</strong></div>`).join("");
    const ruleRows = (items) => items.map(([label, value]) => `<div class="rating-breakdown-row rating-rule-row"><span>${label}</span><strong>${value}</strong></div>`).join("");
    const personalBreakdown = ratingRows([
      ["Категорированные маршруты", scores.routeScore],
      ["Однодневные походы", scores.weekendHikes],
      ["Вершины и перевалы", scores.peaks],
      ["Физические нормативы", scores.norms],
      ["Тесты", scores.tests],
      ["Бег", scores.run],
      ["Спортивный разряд", scores.grade],
      ["Соревнования", scores.competitions],
      ["Посещение тренировок", scores.trainingsVisited],
    ]);
    const teamBreakdown = ratingRows([
      ["Организация мероприятий", scores.events],
      ["Соревнования", scores.competitions],
      ["Организация тренировок", scores.trainingsOrganized],
      ["Посещение тренировок", scores.trainingsVisited],
      ["Спортивный разряд", scores.grade],
    ]);
    return `
      <section class="screen" data-screen="profile">
        <header class="screen-heading"><span class="eyebrow">Настройки</span><h1>Профиль</h1></header>
        <article class="profile-hero">
          <div class="person-row">
            ${avatarMarkup()}
            <div class="person-meta">
              <span class="eyebrow">${membershipLabel()}</span>
              <h1>${escapeHtml(state.profile.name)}</h1>
              <p>${profileAge()} лет · ${escapeHtml(state.profile.grade)}</p>
              ${state.profile.memberSince ? `<p class="membership-duration">В «Вертикали» ${daysSince(state.profile.memberSince)} дн. · с ${formatDate(state.profile.memberSince)}</p>` : ""}
            </div>
            <button class="mini-edit" type="button" data-action="edit-profile">Изменить</button>
          </div>
          <div class="rating-grid">
            <div>
              <p class="rating-label">Личный рейтинг</p>
              <p class="rating-value">${formatNumber(scores.personal)}<span>балла</span></p>
            </div>
            <div class="team-score">
              <span>Командный</span>
              <strong>${formatNumber(scores.team)}</strong>
            </div>
          </div>
          <button class="primary-button hero-action" type="button" data-action="download-report">Создать справку</button>
        </article>

        ${promotionCard(scores)}

        <section class="section profile-statistics">
          <div class="section-head"><h2>Краткая статистика</h2></div>
          <div class="metric-grid">
            ${metric("△", scores.routeTotal, "категорированных маршрутов")}
            ${metric("⌁", Object.values(peakCountsByCategory()).reduce((sum, value) => sum + value, 0), "вершин и перевалов")}
            ${metric("✓", scores.trainingCount, "посещённых тренировок")}
            ${metric("★", scores.competitionCount, "участий в соревнованиях")}
            ${metric("↥", `${formatNumber(scores.distance)} км`, "пройдено без бега")}
            ${metric("○", `${formatNumber(state.activity.runTotal)} км`, "километров бега")}
          </div>
        </section>

        <section class="section rating-breakdown-section">
          <div class="section-head"><h2>Начислено сейчас</h2></div>
          <div class="rating-breakdown-grid">
            <article class="rating-breakdown-card">
              <div class="rating-breakdown-head"><span>Личный рейтинг</span><strong>${formatNumber(scores.personal)}</strong></div>
              <div class="rating-breakdown-list">${personalBreakdown}</div>
            </article>
            <article class="rating-breakdown-card">
              <div class="rating-breakdown-head"><span>Командный рейтинг</span><strong>${formatNumber(scores.team)}</strong></div>
              <div class="rating-breakdown-list">${teamBreakdown}</div>
            </article>
          </div>
        </section>

        <section class="section rating-breakdown-section">
          <div class="section-head"><h2>Как начисляются баллы</h2></div>
          <div class="rating-breakdown-grid">
            <article class="rating-breakdown-card">
              <div class="rating-breakdown-head"><span>Личный рейтинг</span><strong>за запись</strong></div>
              <div class="rating-breakdown-list">
                ${ruleRows([
                  ["Горный / пеший многодневный маршрут", "коэф. ×7 / ×5"],
                  ["Водный / спелеомаршрут", "коэф. ×4 / ×3"],
                  ["Однодневный поход", "1 балл"],
                  ["Вершина 3 / 2 / 1 к.с. / н·к", "2,4 / 1,8 / 1,2 / 0,6 балла"],
                  ["Бег", "коэф. ×0,05 за км"],
                  ["Один норматив", "до 5 баллов"],
                  ["Тест", "баллы из записи"],
                  ["Спортивный разряд", "0–12 баллов"],
                  ["Соревнование: участие / 3 / 2 / 1 место", "0,5 / 1 / 2 / 3 балла"],
                  ["Посещённая тренировка", "0,3 балла"],
                ])}
              </div>
            </article>
            <article class="rating-breakdown-card">
              <div class="rating-breakdown-head"><span>Командный рейтинг</span><strong>за действие</strong></div>
              <div class="rating-breakdown-list">
                ${ruleRows([
                  ["Организованное мероприятие", "1 балл"],
                  ["Организованная тренировка", "коэф. ×0,08"],
                  ["Посещённая тренировка", "0,3 балла"],
                  ["Соревнования и спортивный разряд", "баллы как в личном"],
                ])}
              </div>
            </article>
          </div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Уровень участника</h2></div>
          <div class="settings-list">
            <button class="setting-row" type="button" data-action="enter-membership-code">
              <span><strong>${membershipLabel()}</strong><span>Введите выданный код для повышения категории</span></span><b>›</b>
            </button>
          </div>
        </section>

        <section class="section">
          <div class="section-head"><h2>Мои показатели</h2></div>
          <div class="settings-list">
            <button class="setting-row" type="button" data-action="edit-training-stats">
              <span><strong>Тренировки и мероприятия</strong><span>${state.activity.trainingsOrganized} организовано · ${scores.trainingCount} посещено · ${scores.competitionCount} соревн.</span></span><b>›</b>
            </button>
            <button class="setting-row" type="button" data-action="edit-running">
              <span><strong>Бег</strong><span>${formatNumber(state.activity.runToday)} км сегодня · ${formatNumber(state.activity.runWeek)} км за неделю · ${formatNumber(state.activity.runTotal)} км всего</span></span><b>›</b>
            </button>
            <div class="setting-row">
              <span><strong>Пройденный километраж</strong><span>Автоматически из записей о походах, без учёта бега</span></span><b>${formatNumber(scores.distance)} км</b>
            </div>
            <button class="setting-row" type="button" data-action="edit-norms">
              <span><strong>Нормативы</strong><span>${state.norms.length} показателей · результат и цель</span></span><b>›</b>
            </button>
          </div>
        </section>

        <section class="section faq-section">
          <div class="section-head"><h2>FAQ о рейтинге</h2></div>
          <article class="faq-card">
            <span class="faq-kicker">Личный рейтинг</span>
            <h3>Личные достижения участника</h3>
            <ul>
              <li><strong>Туристический опыт:</strong> категорированные маршруты, походы выходного дня, вершины и перевалы.</li>
              <li><strong>Физическая подготовка:</strong> нормативы, тесты и отдельно учтённая дистанция бега.</li>
              <li><strong>Спортивные достижения:</strong> разряд, участие в соревнованиях и занятые места.</li>
              <li><strong>Тренировки:</strong> каждая сохранённая посещённая тренировка.</li>
            </ul>
          </article>
          <article class="faq-card">
            <span class="faq-kicker">Командный рейтинг</span>
            <h3>Вклад в команду и клуб</h3>
            <ul>
              <li><strong>Организация:</strong> проведение мероприятий и тренировок.</li>
              <li><strong>Участие:</strong> посещение тренировок и выступление на соревнованиях.</li>
              <li><strong>Уровень подготовки:</strong> спортивный разряд участника.</li>
            </ul>
          </article>
          <article class="faq-card promotion-faq">
            <span class="faq-kicker">Повышение</span>
            <h3>Категории открываются последовательно</h3>
            <ol>
              <li><strong>Член секции</strong> — начальная категория.</li>
              <li>При личном рейтинге <strong>30 баллов</strong> появляется уведомление о возможности получить код на категорию <strong>«Член команды»</strong>.</li>
              <li>При личном рейтинге <strong>60 баллов</strong> член команды получает уведомление о возможности получить код на категорию <strong>«Член клуба»</strong>.</li>
            </ol>
            <p>Если рейтинг опустится ниже 60 баллов, член клуба станет членом команды. Ниже 30 баллов категория сбрасывается до члена секции. Повторное повышение проходит по коду.</p>
            <p>Для изменения категории введите код, выданный руководителем.</p>
          </article>
        </section>

        <section class="section">
          <div class="settings-list">
            <button class="setting-row" type="button" data-action="download-report">
              <span><strong>Создать Excel-справку</strong><span>Профиль, рейтинг, маршруты и нормативы</span></span><b>›</b>
            </button>
            <div class="setting-row">
              <span><strong>Хранение данных</strong><span>На устройстве с автоматическим резервным восстановлением Android</span></span><b>✓</b>
            </div>
            <div class="setting-row">
              <span><strong>Личный рейтинг</strong><span>Рассчитывается автоматически</span></span><b>${formatNumber(scores.personal)}</b>
            </div>
          </div>
        </section>
      </section>`;
  }

  function formatNorm(value, norm) {
    return norm.type === "time" ? formatTime(value) : `${formatNumber(value, 0)} ${norm.unit}`;
  }

  function formatTime(minutes) {
    const totalSeconds = Math.round(number(minutes) * 60);
    const mins = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(mins).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  function parseTime(value) {
    const raw = String(value).trim();
    const parts = raw.split(":").map(Number);
    if (parts.length === 2 && parts.every(Number.isFinite)) return parts[0] + parts[1] / 60;
    const digits = raw.replace(/\D/g, "");
    if (!digits) return 0;
    if (digits.length <= 2) return number(digits);
    const minutes = number(digits.slice(0, -2));
    const seconds = Math.min(59, number(digits.slice(-2)));
    return minutes + seconds / 60;
  }

  function autoFormatTime(value, finalize = false) {
    const digits = String(value).replace(/\D/g, "").slice(0, 4);
    if (digits.length <= 2) return digits;
    if (digits.length === 3) return finalize ? `0${digits[0]}:${digits.slice(1)}` : digits;
    return `${digits.slice(0, 2)}:${digits.slice(2)}`;
  }

  function formatDateTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "Дата не указана";
    return new Intl.DateTimeFormat("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(date);
  }

  function formatDate(value) {
    if (!value) return "Дата не указана";
    const date = new Date(`${value}T00:00:00`);
    return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("ru-RU");
  }

  function formatHikeDuration(value) {
    const duration = String(value ?? "").trim();
    if (!duration) return "Продолжительность не указана";
    return /^\d+(?:[.,]\d+)?$/.test(duration) ? `${duration} ч` : duration;
  }

  function parseTrainingDuration(value) {
    const [hours, minutes] = String(value ?? "").split(":").map(Number);
    if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return 0;
    return Math.max(0, hours * 60 + minutes);
  }

  function trainingDurationInput(value) {
    const total = Math.max(0, Math.round(number(value)));
    const hours = Math.min(23, Math.floor(total / 60));
    const minutes = total % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  function formatTrainingDuration(value) {
    const total = Math.max(0, Math.round(number(value)));
    if (!total) return "0 мин";
    const hours = Math.floor(total / 60);
    const minutes = total % 60;
    if (!hours) return `${minutes} мин`;
    return minutes ? `${hours} ч ${minutes} мин` : `${hours} ч`;
  }

  function switchTab(tab, scroll = true) {
    activeTab = tab;
    document.querySelectorAll("[data-screen]").forEach((screen) => screen.classList.toggle("active", screen.dataset.screen === tab));
    document.querySelectorAll("[data-tab]").forEach((button) => button.classList.toggle("active", button.dataset.tab === tab));
    document.querySelector("[data-action='open-notes']")?.classList.toggle("active", tab === "notes");
    if (scroll) window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function showDialog(title, body, onSubmit) {
    dialogTitle.textContent = title;
    dialogBody.innerHTML = body;
    submitHandler = onSubmit;
    dialog.showModal();
  }

  function editProfile() {
    const gradeOptions = sportsGrades.map((item) => `<option value="${escapeHtml(item.value)}" ${normalizeGrade(state.profile.grade) === item.value ? "selected" : ""}>${escapeHtml(item.value)}</option>`).join("");
    const today = new Date().toISOString().slice(0, 10);
    showDialog("Профиль участника", `
      <div class="form-grid">
        <div class="form-field full"><label for="profile-name">ФИО</label><input id="profile-name" name="name" value="${escapeHtml(state.profile.name)}" required /></div>
        <div class="form-field full"><label for="profile-birth-date">Дата рождения · день, месяц, год</label><input id="profile-birth-date" name="birthDate" type="date" max="${today}" value="${escapeHtml(state.profile.birthDate ?? "")}" /></div>
        <div class="form-field full"><label for="profile-member-since">С какого года занимаетесь в команде «Вертикаль»</label><input id="profile-member-since" name="memberSince" type="date" max="${today}" value="${escapeHtml(state.profile.memberSince ?? "")}" /></div>
        <div class="grade-score-preview"><span>Баллы за разряд</span><strong id="grade-score-preview">${formatNumber(gradeScoreFor(state.profile.grade), 0)}</strong></div>
        <div class="form-field full"><label for="profile-grade">Разряд</label><select id="profile-grade" name="grade" data-grade-select required>${gradeOptions}</select></div>
        <div class="form-field full"><label for="profile-photo">Фото</label><input id="profile-photo" name="photo" type="file" accept="image/*" /></div>
      </div>`, async (data) => {
        state.profile.name = String(data.get("name")).trim();
        state.profile.birthDate = String(data.get("birthDate") ?? "");
        state.profile.memberSince = String(data.get("memberSince") ?? "");
        state.profile.age = profileAge();
        state.profile.grade = normalizeGrade(data.get("grade"));
        state.profile.gradeScore = gradeScoreFor(state.profile.grade);
        const file = document.querySelector("#profile-photo")?.files?.[0];
        if (file) state.profile.photo = await readImageFile(file);
      });
  }

  function readImageFile(file, maxSize = 1280) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const picture = new Image();
        picture.onload = () => {
          const scale = Math.min(1, maxSize / Math.max(picture.width, picture.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(picture.width * scale));
          canvas.height = Math.max(1, Math.round(picture.height * scale));
          canvas.getContext("2d").drawImage(picture, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL("image/jpeg", 0.78));
        };
        picture.onerror = reject;
        picture.src = String(reader.result);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function editRoutes() {
    const peakCounts = peakCountsByCategory();
    showDialog("Маршруты", `
      <div class="form-section"><h3>Категорированные маршруты</h3><div class="form-grid">
        ${routeNumberField("Горные", "mountain", state.routes.mountain)}
        ${routeNumberField("Пешие (многодневные)", "hiking", state.routes.hiking)}
        ${routeNumberField("Водные", "water", state.routes.water)}
        ${routeNumberField("Спелео", "speleo", state.routes.speleo)}
        <div class="route-score-preview">
          <span>Баллы за маршруты</span>
          <strong id="route-score-preview">${formatNumber(routeScore())}</strong>
          <small>Горные ×7 · Пешие многодневные ×5 · Водные ×4 · Спелео ×3</small>
        </div>
      </div></div>
      <div class="form-section"><h3>Вершины и перевалы по категориям</h3><div class="form-grid">
        ${readOnlyNumberField("3 к.с.", peakCounts["3"])}
        ${readOnlyNumberField("2 к.с.", peakCounts["2"])}
        ${readOnlyNumberField("1 к.с.", peakCounts["1"])}
        ${readOnlyNumberField("н/к", peakCounts.nk)}
      </div></div>
      <p class="form-hint">Эти значения формируются автоматически из отдельных записей в разделе «Маршруты».</p>`, (data) => {
        Object.keys(routeLabels).forEach((key) => { state.routes[key] = number(data.get(key)); });
      });
  }

  function editTrainingStats() {
    showDialog("Тренировки и соревнования", `
      <div class="form-section"><h3>Командный вклад</h3><div class="form-grid">
        ${numberField("Мероприятий", "eventsOrganized", state.activity.eventsOrganized)}
        ${numberField("Участий в соревнованиях", "competitionsParticipated", state.activity.competitionsParticipated)}
        ${numberField("Организовано тренировок", "trainingsOrganized", state.activity.trainingsOrganized)}
      </div></div>`, (data) => {
        ["eventsOrganized", "competitionsParticipated", "trainingsOrganized"].forEach((key) => {
          state.activity[key] = number(data.get(key));
        });
      });
  }

  function editRunning() {
    showDialog("Бег", `
      <div class="form-section"><h3>Бег</h3><div class="form-grid">
        ${numberField("Сегодня, км", "runToday", state.activity.runToday, "0.1")}
        ${numberField("За неделю, км", "runWeek", state.activity.runWeek, "0.1")}
        ${numberField("Всего, км", "runTotal", state.activity.runTotal, "0.1")}
      </div></div>`, (data) => {
        ["runToday", "runWeek", "runTotal"].forEach((key) => {
          state.activity[key] = number(data.get(key));
        });
      });
  }

  function enterMembershipCode() {
    const scores = calculate();
    const requirementText = state.membership.level === "section"
      ? "Для перехода в команду нужен личный рейтинг не ниже 30."
      : state.membership.level === "team"
        ? "Для перехода в клуб нужен личный рейтинг не ниже 60."
        : "Установлена высшая категория участника.";
    showDialog("Код повышения", `
      <div class="code-current"><span>Текущая категория</span><strong>${membershipLabel()}</strong></div>
      <div class="form-field"><label for="membership-code">Код, выданный руководителем</label><input id="membership-code" name="code" autocomplete="off" autocapitalize="none" placeholder="Код" required /></div>
      <p class="form-hint">${requirementText} Изменение категории выполняется по коду руководителя.</p>`, (data) => {
        const code = String(data.get("code") ?? "").toLowerCase().replace(/\s+/g, "");
        if (code === "vertical_section") {
          if (state.membership.level === "section") {
            showToast("Уже установлена категория «Член секции»");
            return false;
          }
          state.membership.level = "section";
          lastPromotionToastKey = "";
          return "Категория изменена: Член секции";
        }
        if (state.membership.level === "section" && code === "vertical_command") {
          if (scores.personal < 30) {
            showToast("Для повышения требуется рейтинг 30");
            return false;
          }
          state.membership.level = "team";
          return "Категория изменена: Член команды";
        }
        if (state.membership.level === "team" && code === "vertical_club") {
          if (scores.personal < 60) {
            showToast("Для повышения требуется рейтинг 60");
            return false;
          }
          state.membership.level = "club";
          return "Категория изменена: Член клуба";
        }
        if (state.membership.level === "section" && code === "vertical_club") {
          showToast("Сначала получите категорию члена команды");
          return false;
        }
        if (state.membership.level === "club") {
          showToast("Установлена высшая категория");
          return false;
        }
        showToast("Код не подходит для текущей категории");
        return false;
      });
  }

  function addTraining() {
    editTraining();
  }

  function editTraining(id = "") {
    const training = state.trainingSessions.find((item) => item.id === id);
    showDialog(training ? "Изменить тренировку" : "Новая тренировка", `
      <div class="form-grid">
        <div class="form-field full"><label for="training-name">Название тренировки</label><input id="training-name" name="name" value="${escapeHtml(training?.name ?? "")}" placeholder="Например, Плавание" required /></div>
        <div class="form-field full"><label for="training-description">Описание</label><textarea id="training-description" name="description" rows="5" placeholder="Цель, содержание и особенности тренировки">${escapeHtml(training?.description ?? "")}</textarea></div>
        <div class="form-field"><label for="training-duration">Общее время тренировки</label><input id="training-duration" name="duration" type="time" value="${trainingDurationInput(training?.durationMinutes)}" required /></div>
        <div class="form-field"><label for="training-distance">Преодолено, км</label><input id="training-distance" name="distance" type="number" min="0" step="0.1" value="${training?.distance ?? 0}" required /></div>
        <div class="form-field full"><label for="training-approach-label">Упражнение в подходах</label><input id="training-approach-label" name="approachLabel" value="${escapeHtml(training?.approachLabel ?? "")}" placeholder="Например, отжимания или дорожки в бассейне" /></div>
        <div class="form-field"><label for="training-approach-count">Количество подходов</label><input id="training-approach-count" name="approachCount" type="number" min="0" step="1" value="${training?.approachCount ?? 0}" required /></div>
        <div class="form-field"><label for="training-actions">Действий в одном подходе</label><input id="training-actions" name="actionsPerApproach" type="number" min="0" step="1" value="${training?.actionsPerApproach ?? 0}" required /></div>
      </div>
      <p class="form-hint">Запись учитывается как одна посещённая тренировка и добавляет по 0,3 балла к личному и командному рейтингу. Километраж тренировки показывается только в её карточке.</p>
      ${training ? `<button class="danger-button" type="button" data-action="delete-training" data-id="${escapeHtml(training.id)}">Удалить тренировку</button>` : ""}`, (data) => {
        const now = new Date().toISOString();
        const record = training ?? { id: crypto.randomUUID(), createdAt: now };
        record.name = String(data.get("name") ?? "").trim();
        record.description = String(data.get("description") ?? "").trim();
        record.durationMinutes = parseTrainingDuration(data.get("duration"));
        record.distance = number(data.get("distance"));
        record.approachLabel = String(data.get("approachLabel") ?? "").trim();
        record.approachCount = Math.max(0, Math.round(number(data.get("approachCount"))));
        record.actionsPerApproach = Math.max(0, Math.round(number(data.get("actionsPerApproach"))));
        record.updatedAt = now;
        if (!training) state.trainingSessions.unshift(record);
        return training ? "Тренировка обновлена" : "Тренировка добавлена: +0,3 к обоим рейтингам";
      });
  }

  function deleteTraining(id) {
    const training = state.trainingSessions.find((item) => item.id === id);
    if (!training || !window.confirm(`Удалить тренировку «${training.name}»?`)) return;
    state.trainingSessions = state.trainingSessions.filter((item) => item.id !== id);
    finishRecordDeletion("Тренировка удалена: −0,3 из обоих рейтингов");
  }

  function addTest() {
    editTest();
  }

  function editTest(id = "") {
    const test = state.tests.find((item) => item.id === id);
    showDialog(test ? "Изменить тест" : "Новый тест", `
      <div class="form-grid">
        <div class="form-field full"><label for="test-name">Название теста</label><input id="test-name" name="name" value="${escapeHtml(test?.name ?? "")}" required /></div>
        <div class="form-field"><label for="test-date">Дата теста</label><input id="test-date" name="date" type="date" value="${escapeHtml(test?.date ?? "")}" required /></div>
        <div class="form-field"><label for="testPoints">Баллы</label><input id="testPoints" name="testPoints" type="number" min="0" step="0.1" value="${test?.points ?? 0}" required /></div>
      </div>
      ${test ? `<button class="danger-button" type="button" data-action="delete-test" data-id="${escapeHtml(test.id)}">Удалить тест</button>` : ""}`, (data) => {
        const record = test ?? { id: crypto.randomUUID() };
        record.name = String(data.get("name")).trim();
        record.date = String(data.get("date"));
        record.points = number(data.get("testPoints"));
        delete record.coefficient;
        if (!test) state.tests.push(record);
        return test ? "Тест обновлён" : "Тест добавлен";
      });
  }

  function deleteTest(id) {
    const test = state.tests.find((item) => item.id === id);
    if (!test || !window.confirm(`Удалить тест «${test.name}»?`)) return;
    state.tests = state.tests.filter((item) => item.id !== id);
    finishRecordDeletion("Тест удалён");
  }

  function addCompetition() {
    editCompetition();
  }

  function editCompetition(id = "") {
    const competition = state.competitions.find((item) => item.id === id);
    const selectedPlace = normalizeCompetitionPlace(competition?.place);
    const placeOption = (value, label) => `<option value="${value}" ${selectedPlace === value ? "selected" : ""}>${label}</option>`;
    showDialog(competition ? "Изменить соревнование" : "Новое соревнование", `
      <div class="form-grid">
        <div class="form-field full"><label for="competition-name">Название соревнования</label><input id="competition-name" name="name" value="${escapeHtml(competition?.name ?? "")}" required /></div>
        <div class="form-field full"><label for="competition-location">Место проведения</label><input id="competition-location" name="location" value="${escapeHtml(competition?.location ?? "")}" required /></div>
        <div class="form-field"><label for="competition-date">Дата</label><input id="competition-date" name="date" type="date" value="${escapeHtml(competition?.date ?? "")}" required /></div>
        <div class="form-field"><label for="competition-place">Результат</label><select id="competition-place" name="place" required>${placeOption("none", "Участие без места · 0,5")}${placeOption("3", "3 место · 1")}${placeOption("2", "2 место · 2")}${placeOption("1", "1 место · 3")}</select></div>
        <div class="form-field full"><label for="competition-photo">Фото с соревнований</label><input id="competition-photo" name="photo" type="file" accept="image/*" capture="environment" /></div>
      </div>
      ${competition ? `<button class="danger-button" type="button" data-action="delete-competition" data-id="${escapeHtml(competition.id)}">Удалить соревнование</button>` : ""}`, async (data) => {
        const record = competition ?? { id: crypto.randomUUID(), photo: "" };
        record.name = String(data.get("name")).trim();
        record.location = String(data.get("location")).trim();
        record.date = String(data.get("date"));
        record.place = normalizeCompetitionPlace(data.get("place"));
        const file = document.querySelector("#competition-photo")?.files?.[0];
        if (file) record.photo = await readImageFile(file);
        if (!competition) state.competitions.push(record);
        state.activity.competitionsParticipated = Math.max(number(state.activity.competitionsParticipated), state.competitions.length);
        return competition ? "Соревнование обновлено" : "Соревнование добавлено";
      });
  }

  function deleteCompetition(id) {
    const competition = state.competitions.find((item) => item.id === id);
    if (!competition || !window.confirm(`Удалить соревнование «${competition.name}»?`)) return;
    state.competitions = state.competitions.filter((item) => item.id !== id);
    state.activity.competitionsParticipated = Math.max(state.competitions.length, number(state.activity.competitionsParticipated) - 1);
    finishRecordDeletion("Соревнование удалено");
  }

  function addRunTrack() {
    editRunTrack();
  }

  function editRunTrack(id = "") {
    const track = state.runTracks.find((item) => item.id === id);
    showDialog(track ? "Изменить трек бега" : "Новый трек бега", `
      <div class="form-grid">
        <div class="form-field full"><label for="run-track-name">Название пробежки</label><input id="run-track-name" name="name" value="${escapeHtml(track?.name ?? "")}" placeholder="Например, Вечерняя пробежка" required /></div>
        <div class="form-field full"><label for="run-track-route">Маршрут</label><input id="run-track-route" name="route" value="${escapeHtml(track?.route ?? "")}" placeholder="Старт, ключевые точки и финиш" required /></div>
        <div class="form-field"><label for="run-track-distance">Дистанция, км</label><input id="run-track-distance" name="distance" type="number" min="0.1" step="0.1" value="${track?.distance ?? 1}" required /></div>
        <div class="form-field"><label for="run-track-date">Дата и время</label><input id="run-track-date" name="runAt" type="datetime-local" step="1" value="${escapeHtml(String(track?.runAt ?? "").slice(0, 19))}" required /></div>
        <div class="form-field full"><label for="run-track-photo">Фото или скриншот трека</label><input id="run-track-photo" name="photo" type="file" accept="image/*" capture="environment" /></div>
        <div class="form-field full"><label for="run-track-note">Заметка</label><textarea id="run-track-note" name="note" rows="5" placeholder="Темп, самочувствие и особенности маршрута">${escapeHtml(track?.note ?? "")}</textarea></div>
      </div>
      <p class="form-hint">Дистанция трека прибавляется только к итоговому километражу бега.</p>
      ${track ? `<button class="danger-button" type="button" data-action="delete-run-track" data-id="${escapeHtml(track.id)}">Удалить трек</button>` : ""}`, async (data) => {
        const previousDistance = number(track?.distance);
        const record = track ?? { id: crypto.randomUUID(), photo: "" };
        record.name = String(data.get("name")).trim();
        record.route = String(data.get("route")).trim();
        record.distance = number(data.get("distance"));
        record.runAt = String(data.get("runAt") ?? "");
        record.note = String(data.get("note") ?? "").trim();
        const file = document.querySelector("#run-track-photo")?.files?.[0];
        if (file) record.photo = await readImageFile(file);
        state.activity.runTotal = Math.max(0, number(state.activity.runTotal) - previousDistance + record.distance);
        if (!track) state.runTracks.unshift(record);
        return track ? "Трек бега обновлён" : `Трек добавлен: +${formatNumber(record.distance)} км к бегу`;
      });
  }

  function deleteRunTrack(id) {
    const track = state.runTracks.find((item) => item.id === id);
    if (!track || !window.confirm(`Удалить трек «${track.name}»?`)) return;
    state.activity.runTotal = Math.max(0, number(state.activity.runTotal) - number(track.distance));
    state.runTracks = state.runTracks.filter((item) => item.id !== id);
    finishRecordDeletion("Трек бега удалён");
  }

  function addWeekendHike() {
    editWeekendHike();
  }

  function editWeekendHike(id = "") {
    const hike = state.weekendHikes.find((item) => item.id === id);
    showDialog(hike ? "Изменить поход" : "Новый поход выходного дня", `
      <div class="form-grid">
        <div class="form-field full"><label for="weekend-hike-name">Название похода</label><input id="weekend-hike-name" name="name" value="${escapeHtml(hike?.name ?? "")}" placeholder="Например, Титовская сопка" required /></div>
        <div class="form-field full"><label for="weekend-hike-location">Район или маршрут</label><input id="weekend-hike-location" name="location" value="${escapeHtml(hike?.location ?? "")}" placeholder="Откуда и куда проходил маршрут" required /></div>
        <div class="form-field full"><label for="weekend-hike-date">Дата похода</label><input id="weekend-hike-date" name="date" type="date" value="${escapeHtml(hike?.date ?? "")}" required /></div>
        <div class="form-field"><label for="weekend-hike-duration">Продолжительность</label><input id="weekend-hike-duration" name="duration" value="${escapeHtml(hike?.duration ?? "")}" placeholder="Например, 6 часов" required /></div>
        <div class="form-field"><label for="weekend-hike-distance">Расстояние, км</label><input id="weekend-hike-distance" name="distance" type="number" min="0.1" step="0.1" value="${hike?.distance ?? 1}" required /></div>
        <div class="form-field full"><label for="weekend-hike-description">Описание</label><textarea id="weekend-hike-description" name="description" rows="6" placeholder="Участники, особенности маршрута и другая информация">${escapeHtml(hike?.description ?? "")}</textarea></div>
      </div>
      <p class="form-hint">Запись добавляет 1 балл к личному рейтингу. Расстояние учитывается в пройденном километраже отдельно от бега.</p>
      ${hike ? `<button class="danger-button" type="button" data-action="delete-weekend-hike" data-id="${escapeHtml(hike.id)}">Удалить поход</button>` : ""}`, (data) => {
        const record = hike ?? { id: crypto.randomUUID() };
        record.name = String(data.get("name")).trim();
        record.location = String(data.get("location")).trim();
        record.date = String(data.get("date"));
        record.duration = String(data.get("duration")).trim();
        record.distance = number(data.get("distance"));
        record.description = String(data.get("description") ?? "").trim();
        if (!hike) state.weekendHikes.unshift(record);
        return hike ? "Поход обновлён" : `Поход добавлен: +1 к рейтингу и ${formatNumber(record.distance)} км пройдено`;
      });
  }

  function deleteWeekendHike(id) {
    const hike = state.weekendHikes.find((item) => item.id === id);
    if (!hike || !window.confirm(`Удалить поход «${hike.name}»?`)) return;
    state.weekendHikes = state.weekendHikes.filter((item) => item.id !== id);
    finishRecordDeletion("Поход удалён: −1 балл рейтинга");
  }

  function addNote() {
    editNote();
  }

  function editNote(id = "") {
    const note = state.notes.find((item) => item.id === id);
    showDialog(note ? "Изменить заметку" : "Новая заметка", `
      <div class="form-grid">
        <div class="form-field full"><label for="note-title">Название заметки</label><input id="note-title" name="title" maxlength="80" value="${escapeHtml(note?.title ?? "")}" required /></div>
        <div class="form-field full"><label for="note-text">Текст заметки</label><textarea id="note-text" name="text" rows="8" placeholder="Введите любую дополнительную информацию" required>${escapeHtml(note?.text ?? "")}</textarea></div>
      </div>
      ${note ? `<button class="danger-button" type="button" data-action="delete-note" data-id="${escapeHtml(note.id)}">Удалить заметку</button>` : ""}`, (data) => {
        const now = new Date().toISOString();
        const record = note ?? { id: crypto.randomUUID(), createdAt: now };
        record.title = String(data.get("title") ?? "").trim();
        record.text = String(data.get("text")).trim();
        record.updatedAt = now;
        if (!note) state.notes.unshift(record);
        return note ? "Заметка обновлена" : "Заметка добавлена";
      });
  }

  function deleteNote(id) {
    const note = state.notes.find((item) => item.id === id);
    if (!note || !window.confirm("Удалить эту заметку?")) return;
    state.notes = state.notes.filter((item) => item.id !== id);
    finishRecordDeletion("Заметка удалена");
  }

  function finishRecordDeletion(message) {
    saveState();
    if (dialog.open) dialog.close();
    render();
    showToast(message);
  }

  function numberField(label, name, value, step = "1") {
    return `<div class="form-field"><label for="${name}">${label}</label><input id="${name}" name="${name}" type="number" min="0" step="${step}" value="${value}" required /></div>`;
  }

  function readOnlyNumberField(label, value) {
    return `<div class="form-field"><label>${label}</label><input type="number" value="${number(value)}" readonly aria-readonly="true" /></div>`;
  }

  function routeNumberField(label, name, value) {
    return `<div class="form-field"><label for="${name}">${label} · ×${routeCoefficients[name]}</label><input id="${name}" name="${name}" type="number" min="0" step="1" value="${value}" data-route-input data-route-key="${name}" required /></div>`;
  }

  function addPeak() {
    editPeak();
  }

  function editPeak(id = "") {
    const peak = state.peaks.find((item) => item.id === id);
    const selectedCategory = peak?.category ?? "3";
    const option = (value, label) => `<option value="${value}" ${selectedCategory === value ? "selected" : ""}>${label}</option>`;
    showDialog(peak ? "Изменить восхождение" : "Новое восхождение", `
      <div class="form-grid">
        <div class="form-field full"><label for="peak-name">Название вершины или перевала</label><input id="peak-name" name="name" value="${escapeHtml(peak?.name ?? "")}" placeholder="Например, Кодар" required /></div>
        <div class="form-field"><label for="peak-category">Категория</label><select id="peak-category" name="category">${option("3", "3 к.с.")}${option("2", "2 к.с.")}${option("1", "1 к.с.")}${option("nk", "н/к")}</select></div>
        ${numberField("Количество восхождений", "count", peak?.count ?? 1)}
        <div class="form-field full"><label for="peak-date">Дата и точное время покорения</label><input id="peak-date" name="conqueredAt" type="datetime-local" step="1" value="${escapeHtml(String(peak?.conqueredAt ?? "").slice(0, 19))}" /></div>
        <div class="form-field full"><label for="peak-photo">Фото с восхождения</label><input id="peak-photo" name="photo" type="file" accept="image/*" capture="environment" /></div>
      </div>
      ${peak ? `<button class="danger-button" type="button" data-action="delete-peak" data-id="${escapeHtml(peak.id)}">Удалить запись о вершине</button>` : ""}`, async (data) => {
        const record = peak ?? { id: crypto.randomUUID(), photo: "" };
        record.name = String(data.get("name")).trim();
        record.category = String(data.get("category"));
        record.count = number(data.get("count"), 1);
        record.conqueredAt = String(data.get("conqueredAt") ?? "");
        const file = document.querySelector("#peak-photo")?.files?.[0];
        if (file) record.photo = await readImageFile(file);
        if (!peak) state.peaks.push(record);
        return peak ? "Запись о вершине обновлена" : "Восхождение добавлено";
      });
  }

  function deletePeak(id) {
    const peak = state.peaks.find((item) => item.id === id);
    if (!peak || !window.confirm(`Удалить запись «${peak.name}»?`)) return;
    state.peaks = state.peaks.filter((item) => item.id !== id);
    saveState();
    dialog.close();
    render();
    showToast("Запись о вершине удалена");
  }

  function editNorms() {
    const fields = state.norms.map((norm) => `
      <div class="form-section"><h3>${escapeHtml(norm.name)}</h3><div class="form-grid">
        <div class="form-field"><label for="${norm.id}-current">Результат</label><input id="${norm.id}-current" name="${norm.id}-current" ${norm.type === "count" ? 'type="number" min="0"' : 'type="text" inputmode="numeric" data-time-input maxlength="5" placeholder="0400"'} value="${norm.type === "time" ? formatTime(norm.current) : norm.current}" required /></div>
        <div class="form-field"><label for="${norm.id}-target">Норматив</label><input id="${norm.id}-target" name="${norm.id}-target" ${norm.type === "count" ? 'type="number" min="0"' : 'type="text" inputmode="numeric" data-time-input maxlength="5" placeholder="0500"'} value="${norm.type === "time" ? formatTime(norm.target) : norm.target}" required /></div>
      </div></div>`).join("");

    showDialog("Нормативы", fields, (data) => {
      state.norms.forEach((norm) => {
        const parser = norm.type === "time" ? parseTime : number;
        norm.current = parser(data.get(`${norm.id}-current`));
        norm.target = parser(data.get(`${norm.id}-target`));
      });
    });
  }

  function showToast(message) {
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add("show");
    toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2600);
  }

  function xmlEscape(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&apos;");
  }

  function excelColumn(index) {
    let value = index + 1;
    let result = "";
    while (value > 0) {
      value -= 1;
      result = String.fromCharCode(65 + (value % 26)) + result;
      value = Math.floor(value / 26);
    }
    return result;
  }

  function makeReportRows() {
    const scores = calculate();
    const rows = [];
    const title = (value) => rows.push([{ value, style: 1 }, null, null, null, null]);
    const section = (value) => rows.push([{ value, style: 2 }, null, null, null, null]);
    const item = (label, value, extra = "", valueStyle = 0) => rows.push([{ value: label, style: 3 }, { value, style: valueStyle }, { value: extra }, null, null]);

    title("СПРАВКА УЧАСТНИКА КЛУБА «ВЕРТИКАЛЬ»");
    item("Дата формирования", new Date().toLocaleDateString("ru-RU"));
    rows.push([]);
    section("ПРОФИЛЬ");
    item("ФИО", state.profile.name);
    item("Категория участника", membershipLabel());
    item("Дата рождения", state.profile.birthDate ? formatDate(state.profile.birthDate) : "Не указана");
    item("Возраст", profileAge(), "лет");
    item("В команде «Вертикаль» с", state.profile.memberSince ? formatDate(state.profile.memberSince) : "Не указано");
    item("Дней в команде", daysSince(state.profile.memberSince));
    item("Спортивный разряд", state.profile.grade);
    item("Баллы за спортивный разряд", state.profile.gradeScore, "", 6);
    item("Личный рейтинг", scores.personal, "", 6);
    item("Командный рейтинг", scores.team, "", 6);
    rows.push([]);
    section("МАРШРУТЫ");
    item("Категорированных маршрутов", scores.routeTotal);
    Object.entries(routeLabels).forEach(([key, label]) => item(label, state.routes[key]));
    item("Баллы за маршруты", scores.routeScore, "", 6);
    item("Походов выходного дня", state.weekendHikes.length);
    item("Баллы за походы выходного дня", scores.weekendHikes, "", 6);
    if (state.weekendHikes.length) {
      rows.push([]);
      section("ПОХОДЫ ВЫХОДНОГО ДНЯ");
      rows.push([{ value: "Название", style: 4 }, { value: "Маршрут и описание", style: 4 }, { value: "Дата", style: 4 }, { value: "Продолжительность", style: 4 }, { value: "Расстояние, км", style: 4 }]);
      state.weekendHikes.forEach((hike) => rows.push([
        { value: hike.name },
        { value: `${hike.location}${hike.description ? ` · ${hike.description}` : ""}` },
        { value: formatDate(hike.date) },
        { value: formatHikeDuration(hike.duration) },
        { value: number(hike.distance), style: 6 },
      ]));
    }
    rows.push([]);
    section("ВЕРШИНЫ И ПЕРЕВАЛЫ");
    rows.push([
      { value: "Название", style: 4 },
      { value: "Категория", style: 4 },
      { value: "Восхождений", style: 4 },
      { value: "Дата и время", style: 4 },
      { value: "Баллы", style: 4 },
    ]);
    state.peaks.forEach((peak) => rows.push([
      { value: peak.name },
      { value: peak.category === "nk" ? "н/к" : `${peak.category} к.с.` },
      { value: peak.count },
      { value: peak.conqueredAt ? formatDateTime(peak.conqueredAt) : "Не указана" },
      { value: peakScore(peak), style: 6 },
    ]));
    rows.push([]);
    section("АКТИВНОСТЬ");
    item("Организовано мероприятий", state.activity.eventsOrganized);
    item("Участие в соревнованиях", state.activity.competitionsParticipated);
    item("Баллы за соревнования", scores.competitions, "", 6);
    item("Организовано тренировок", state.activity.trainingsOrganized);
    item("Посещено тренировок", scores.trainingCount);
    item("Баллы за посещённые тренировки", scores.trainingsVisited, "", 6);
    item("Пройденный километраж без бега", scores.distance, "км");
    item("Километраж бега", state.activity.runTotal, "км");
    item("Записано треков бега", state.runTracks.length);
    if (state.trainingSessions.length) {
      rows.push([]);
      section("ТРЕНИРОВКИ");
      rows.push([{ value: "Название", style: 4 }, { value: "Описание", style: 4 }, { value: "Время", style: 4 }, { value: "Км", style: 4 }, { value: "Подходы", style: 4 }]);
      state.trainingSessions.forEach((training) => rows.push([
        { value: training.name },
        { value: training.description || "Без описания" },
        { value: formatTrainingDuration(training.durationMinutes) },
        { value: number(training.distance), style: 6 },
        { value: `${training.approachLabel || "Упражнение не указано"} · ${number(training.approachCount)} × ${number(training.actionsPerApproach)}` },
      ]));
    }
    if (state.runTracks.length) {
      rows.push([]);
      section("ТРЕКИ БЕГА");
      rows.push([{ value: "Название", style: 4 }, { value: "Маршрут", style: 4 }, { value: "Дата и время", style: 4 }, { value: "Дистанция", style: 4 }, { value: "Фото / заметка", style: 4 }]);
      state.runTracks.forEach((track) => rows.push([
        { value: track.name },
        { value: track.route },
        { value: track.runAt ? formatDateTime(track.runAt) : "Не указана" },
        { value: track.distance, style: 6 },
        { value: `${track.photo ? "Фото приложено" : "Без фото"}${track.note ? ` · ${track.note}` : ""}` },
      ]));
    }
    if (state.competitions.length) {
      rows.push([]);
      section("СОРЕВНОВАНИЯ");
      rows.push([{ value: "Название", style: 4 }, { value: "Место проведения", style: 4 }, { value: "Дата", style: 4 }, { value: "Результат / фото", style: 4 }, { value: "Баллы", style: 4 }]);
      state.competitions.forEach((competition) => rows.push([
        { value: competition.name },
        { value: competition.location },
        { value: formatDate(competition.date) },
        { value: `${competitionPlaceLabel(competition.place)} · ${competition.photo ? "Фото приложено" : "Без фото"}` },
        { value: competitionScore(competition), style: 6 },
      ]));
    }
    if (state.tests.length) {
      rows.push([]);
      section("ТЕСТЫ");
      rows.push([{ value: "Название", style: 4 }, { value: "Дата", style: 4 }, { value: "Баллы в рейтинг", style: 4 }, null, null]);
      state.tests.forEach((test) => rows.push([
        { value: test.name },
        { value: test.date ? formatDate(test.date) : "Не указана" },
        { value: testScore(test), style: 6 },
        null,
        null,
      ]));
    }
    rows.push([]);
    section("НОРМАТИВЫ");
    rows.push([
      { value: "Норматив", style: 4 },
      { value: "Результат", style: 4 },
      { value: "Цель", style: 4 },
      { value: "Выполнение", style: 4 },
    ]);
    state.norms.forEach((norm) => rows.push([
      { value: norm.name },
      { value: formatNorm(norm.current, norm) },
      { value: formatNorm(norm.target, norm) },
      { value: normScore(norm), style: 5 },
    ]));
    if (state.notes.length) {
      rows.push([]);
      section("ЗАМЕТКИ");
      state.notes.forEach((note) => item(note.title || "Без названия", note.text, new Date(note.updatedAt || note.createdAt).toLocaleString("ru-RU")));
    }

    return rows;
  }

  function worksheetXml(rows) {
    const rowXml = rows.map((row, rowIndex) => {
      const cells = (row ?? []).map((cell, colIndex) => {
        if (!cell || cell.value === null || cell.value === "") return "";
        const ref = `${excelColumn(colIndex)}${rowIndex + 1}`;
        const style = cell.style ? ` s="${cell.style}"` : "";
        if (typeof cell.value === "number") return `<c r="${ref}"${style}><v>${cell.value}</v></c>`;
        return `<c r="${ref}" t="inlineStr"${style}><is><t xml:space="preserve">${xmlEscape(cell.value)}</t></is></c>`;
      }).join("");
      return `<row r="${rowIndex + 1}" ht="21" customHeight="1">${cells}</row>`;
    }).join("");

    const sectionMerges = rows
      .map((row, index) => row?.[0]?.style === 1 || row?.[0]?.style === 2 ? `A${index + 1}:E${index + 1}` : null)
      .filter(Boolean);

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
      <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
        <sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen" /></sheetView></sheetViews>
        <cols><col min="1" max="1" width="36" customWidth="1"/><col min="2" max="2" width="24" customWidth="1"/><col min="3" max="3" width="22" customWidth="1"/><col min="4" max="5" width="18" customWidth="1"/></cols>
        <sheetData>${rowXml}</sheetData>
        <mergeCells count="${sectionMerges.length}">${sectionMerges.map((ref) => `<mergeCell ref="${ref}"/>`).join("")}</mergeCells>
        <pageMargins left="0.35" right="0.35" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>
      </worksheet>`;
  }

  async function downloadReport() {
    if (!window.JSZip) {
      showToast("Модуль Excel не загрузился");
      return;
    }

    const zip = new JSZip();
    const now = new Date().toISOString();
    const rows = makeReportRows();
    zip.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`);
    zip.folder("_rels").file(".rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`);
    zip.folder("docProps").file("core.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Справка участника клуба Вертикаль</dc:title><dc:creator>Вертикаль</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created></cp:coreProperties>`);
    zip.folder("docProps").file("app.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Вертикаль</Application></Properties>`);
    zip.folder("xl").file("workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Справка" sheetId="1" r:id="rId1"/></sheets></workbook>`);
    zip.folder("xl").folder("_rels").file("workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
    zip.folder("xl").file("styles.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="2"><numFmt numFmtId="164" formatCode="0%"/><numFmt numFmtId="165" formatCode="0.0"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Arial"/></font><font><b/><color rgb="FF050505"/><sz val="16"/><name val="Arial"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Arial"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF00AEEF"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FF050505"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><bottom style="thin"><color rgb="33000000"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="7"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/><xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`);
    zip.folder("xl").folder("worksheets").file("sheet1.xml", worksheetXml(rows));

    const mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    const blob = await zip.generateAsync({ type: "blob", mimeType, compression: "DEFLATE" });
    const filename = `Справка_Вертикаль_${new Date().toISOString().slice(0, 10)}.xlsx`;

    if (window.Android?.saveBase64File || window.webkit?.messageHandlers?.saveFile) {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let binary = "";
      for (let offset = 0; offset < bytes.length; offset += 0x8000) {
        binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
      }
      const base64 = btoa(binary);
      if (window.Android?.saveBase64File) {
        window.Android.saveBase64File(base64, filename, mimeType);
      } else {
        window.webkit.messageHandlers.saveFile.postMessage({ base64, filename, mimeType });
      }
      showToast("Excel-справка сохраняется");
      return;
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 3000);
    showToast("Excel-справка создана");
  }

  document.addEventListener("click", (event) => {
    const nav = event.target.closest("[data-tab]");
    if (nav) return switchTab(nav.dataset.tab);

    const actionElement = event.target.closest("[data-action]");
    const action = actionElement?.dataset.action;
    if (!action) return;
    if (action === "go-home") return switchTab("profile");
    if (action === "open-notes") return switchTab("notes");
    if (action === "download-report") return downloadReport();
    if (action === "edit-profile") return editProfile();
    if (action === "edit-routes") return editRoutes();
    if (action === "edit-training-stats") return editTrainingStats();
    if (action === "add-training") return addTraining();
    if (action === "edit-training") return editTraining(actionElement.dataset.id);
    if (action === "delete-training") return deleteTraining(actionElement.dataset.id);
    if (action === "edit-running") return editRunning();
    if (action === "edit-norms") return editNorms();
    if (action === "add-peak") return addPeak();
    if (action === "edit-peak") return editPeak(actionElement.dataset.id);
    if (action === "delete-peak") return deletePeak(actionElement.dataset.id);
    if (action === "enter-membership-code") return enterMembershipCode();
    if (action === "add-test") return addTest();
    if (action === "edit-test") return editTest(actionElement.dataset.id);
    if (action === "delete-test") return deleteTest(actionElement.dataset.id);
    if (action === "add-competition") return addCompetition();
    if (action === "edit-competition") return editCompetition(actionElement.dataset.id);
    if (action === "delete-competition") return deleteCompetition(actionElement.dataset.id);
    if (action === "add-run-track") return addRunTrack();
    if (action === "edit-run-track") return editRunTrack(actionElement.dataset.id);
    if (action === "delete-run-track") return deleteRunTrack(actionElement.dataset.id);
    if (action === "add-weekend-hike") return addWeekendHike();
    if (action === "edit-weekend-hike") return editWeekendHike(actionElement.dataset.id);
    if (action === "delete-weekend-hike") return deleteWeekendHike(actionElement.dataset.id);
    if (action === "add-note") return addNote();
    if (action === "edit-note") return editNote(actionElement.dataset.id);
    if (action === "delete-note") return deleteNote(actionElement.dataset.id);
    if (action === "close-dialog") return dialog.close();
  });

  document.addEventListener("submit", (event) => {
    const publisher = event.target.closest("[data-note-publisher]");
    if (!publisher) return;
    event.preventDefault();
    const data = new FormData(publisher);
    const now = new Date().toISOString();
    state.notes.unshift({
      id: crypto.randomUUID(),
      title: String(data.get("title") ?? "").trim(),
      text: String(data.get("text") ?? "").trim(),
      createdAt: now,
      updatedAt: now,
    });
    saveState();
    render();
    switchTab("notes", false);
    showToast("Заметка опубликована");
  });

  document.addEventListener("input", (event) => {
    const input = event.target.closest("[data-time-input]");
    if (!input) return;
    input.value = autoFormatTime(input.value);
  });

  document.addEventListener("input", (event) => {
    if (!event.target.closest("[data-route-input]")) return;
    const currentRoutes = {};
    Object.keys(routeLabels).forEach((key) => {
      currentRoutes[key] = number(document.querySelector(`[data-route-key="${key}"]`)?.value);
    });
    const preview = document.querySelector("#route-score-preview");
    if (preview) preview.textContent = formatNumber(routeScore(currentRoutes));
  });

  document.addEventListener("focusout", (event) => {
    const input = event.target.closest("[data-time-input]");
    if (!input) return;
    input.value = autoFormatTime(input.value, true);
  });

  document.addEventListener("change", (event) => {
    const select = event.target.closest("[data-grade-select]");
    if (!select) return;
    const preview = document.querySelector("#grade-score-preview");
    if (preview) preview.textContent = formatNumber(gradeScoreFor(select.value), 0);
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!submitHandler) return;
    const data = new FormData(form);
    const result = await submitHandler(data);
    if (result === false) return;
    saveState();
    dialog.close();
    render();
    showToast(typeof result === "string" ? result : "Данные сохранены на устройстве");
  });

  dialog.addEventListener("click", (event) => {
    const rect = dialog.getBoundingClientRect();
    const inside = event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
    if (!inside) dialog.close();
  });

  saveState();
  render();
})();
