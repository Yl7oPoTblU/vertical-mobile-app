from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os
import subprocess
import threading
import time


APP_DIRECTORY = Path(__file__).resolve().parent
APP_URL = "http://127.0.0.1:8080/"


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass


os.chdir(APP_DIRECTORY)
server = ThreadingHTTPServer(("127.0.0.1", 8080), QuietHandler)
server_thread = threading.Thread(target=server.serve_forever, daemon=True)
server_thread.start()

print("Вертикаль запускается...")
time.sleep(0.7)

try:
    subprocess.run(["internalbrowser", APP_URL], check=False)
    while True:
        time.sleep(60)
except KeyboardInterrupt:
    pass
finally:
    server.shutdown()
    server.server_close()
    print("Вертикаль остановлена")
