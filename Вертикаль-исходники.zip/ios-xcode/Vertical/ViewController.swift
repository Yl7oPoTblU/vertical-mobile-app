import UIKit
import WebKit

final class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UIDocumentPickerDelegate {
    private let stateStore = StateStore()
    private var webView: WKWebView!
    private var needsCloudRestore = false
    private var temporaryExport: URL?

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 5 / 255, green: 5 / 255, blue: 5 / 255, alpha: 1)

        let localState = stateStore.loadLocal()
        needsCloudRestore = localState == nil

        let contentController = WKUserContentController()
        contentController.add(self, name: "saveState")
        contentController.add(self, name: "saveFile")

        let bootstrap: String
        if let localState {
            bootstrap = "window.__VERTICAL_NATIVE_BACKUP__ = \(javaScriptLiteral(localState)); window.__VERTICAL_AWAITING_CLOUD_RESTORE__ = false;"
        } else {
            bootstrap = "window.__VERTICAL_NATIVE_BACKUP__ = ''; window.__VERTICAL_AWAITING_CLOUD_RESTORE__ = true;"
        }
        contentController.addUserScript(WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        let configuration = WKWebViewConfiguration()
        configuration.userContentController = contentController
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.websiteDataStore = .default()

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.backgroundColor = view.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])

        guard let indexURL = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") else {
            presentError("Не удалось загрузить интерфейс приложения")
            return
        }
        let webFolder = indexURL.deletingLastPathComponent()
        webView.loadFileURL(indexURL, allowingReadAccessTo: webFolder)
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "saveState")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "saveFile")
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard needsCloudRestore else { return }
        needsCloudRestore = false
        stateStore.loadFromICloud { [weak self] restoredState in
            DispatchQueue.main.async {
                guard let self else { return }
                let script: String
                if let restoredState, !restoredState.isEmpty {
                    script = "window.VerticalNativeRestore?.(\(self.javaScriptLiteral(restoredState)));"
                } else {
                    script = "window.VerticalNativeFinishRestore?.();"
                }
                self.webView.evaluateJavaScript(script)
            }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case "saveState":
            guard let json = message.body as? String else { return }
            stateStore.save(json)
        case "saveFile":
            guard
                let payload = message.body as? [String: Any],
                let base64 = payload["base64"] as? String,
                let filename = payload["filename"] as? String,
                let data = Data(base64Encoded: base64, options: .ignoreUnknownCharacters)
            else { return }
            export(data: data, filename: sanitizedFilename(filename))
        default:
            break
        }
    }

    private func export(data: Data, filename: String) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("VerticalExports", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let fileURL = folder.appendingPathComponent(filename)
            try data.write(to: fileURL, options: .atomic)
            temporaryExport = fileURL
            let picker = UIDocumentPickerViewController(forExporting: [fileURL], asCopy: true)
            picker.delegate = self
            present(picker, animated: true)
        } catch {
            presentError("Не удалось подготовить Excel-справку")
        }
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        clearTemporaryExport()
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        clearTemporaryExport()
    }

    private func clearTemporaryExport() {
        if let temporaryExport {
            try? FileManager.default.removeItem(at: temporaryExport)
        }
        temporaryExport = nil
    }

    private func sanitizedFilename(_ value: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\:*?\"<>|")
        let safe = value.components(separatedBy: invalid).joined(separator: "_")
        return safe.lowercased().hasSuffix(".xlsx") ? safe : safe + ".xlsx"
    }

    private func javaScriptLiteral(_ value: String) -> String {
        guard
            let data = try? JSONSerialization.data(withJSONObject: value, options: .fragmentsAllowed),
            let literal = String(data: data, encoding: .utf8)
        else { return "\"\"" }
        return literal
    }

    private func presentError(_ message: String) {
        let alert = UIAlertController(title: "Вертикаль", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ОК", style: .default))
        present(alert, animated: true)
    }
}
