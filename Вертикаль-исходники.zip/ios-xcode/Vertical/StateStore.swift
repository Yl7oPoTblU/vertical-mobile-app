import Foundation

final class StateStore {
    private let localKey = "vertical-mobile-profile-v2"
    private let containerIdentifier = "iCloud.ru.tskvertical.app"
    private let queue = DispatchQueue(label: "ru.tskvertical.state-store", qos: .utility)

    func loadLocal() -> String? {
        let value = UserDefaults.standard.string(forKey: localKey)
        return value?.isEmpty == false ? value : nil
    }

    func save(_ json: String) {
        guard !json.isEmpty else { return }
        UserDefaults.standard.set(json, forKey: localKey)
        queue.async { [weak self] in
            self?.writeToICloud(json)
        }
    }

    func loadFromICloud(completion: @escaping (String?) -> Void) {
        loadFromICloud(attemptsRemaining: 6, completion: completion)
    }

    private func loadFromICloud(attemptsRemaining: Int, completion: @escaping (String?) -> Void) {
        queue.async { [weak self] in
            guard let self else {
                completion(nil)
                return
            }
            guard let fileURL = self.cloudFileURL() else {
                if attemptsRemaining > 1 {
                    self.queue.asyncAfter(deadline: .now() + 1) {
                        self.loadFromICloud(attemptsRemaining: attemptsRemaining - 1, completion: completion)
                    }
                } else {
                    completion(nil)
                }
                return
            }
            guard FileManager.default.fileExists(atPath: fileURL.path) else {
                completion(nil)
                return
            }

            var coordinatorError: NSError?
            var restoredState: String?
            NSFileCoordinator().coordinate(readingItemAt: fileURL, options: [], error: &coordinatorError) { coordinatedURL in
                restoredState = try? String(contentsOf: coordinatedURL, encoding: .utf8)
            }
            completion(restoredState)
        }
    }

    private func writeToICloud(_ json: String) {
        guard let fileURL = cloudFileURL() else { return }
        let folderURL = fileURL.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true)

        var coordinatorError: NSError?
        NSFileCoordinator().coordinate(writingItemAt: fileURL, options: .forReplacing, error: &coordinatorError) { coordinatedURL in
            guard let data = json.data(using: .utf8) else { return }
            try? data.write(to: coordinatedURL, options: .atomic)
        }
    }

    private func cloudFileURL() -> URL? {
        guard let containerURL = FileManager.default.url(forUbiquityContainerIdentifier: containerIdentifier) else {
            return nil
        }
        return containerURL
            .appendingPathComponent("Documents", isDirectory: true)
            .appendingPathComponent("Vertical", isDirectory: true)
            .appendingPathComponent("state.json", isDirectory: false)
    }
}
